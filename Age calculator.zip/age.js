function calculateAge() {
    const birthdate = new Date(document.getElementById("birthdate").value);
    const today = new Date();
  
    if (!birthdate || birthdate > today) {
      document.getElementById("result").innerText = "Please enter a valid birth date.";
      return;
    }
  
    let years = today.getFullYear() - birthdate.getFullYear();
    let months = today.getMonth() - birthdate.getMonth();
    let days = today.getDate() - birthdate.getDate();
  
    if (days < 0) {
      months--;
      days += new Date(today.getFullYear(), today.getMonth(), 0).getDate();
    }
  
    if (months < 0) {
      years--;
      months += 12;
    }
  
    document.getElementById("result").innerText = 
      `You are ${years} years, ${months} months, and ${days} days old.`;
  }
  